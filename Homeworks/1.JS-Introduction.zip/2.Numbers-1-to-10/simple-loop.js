// Problem 2. Numbers 1...10
// Write a JavaScript program numbers1to10.js that prints on the console
// the numbers from 1 to 10 (each at a separate line).
// Run the program through Node.js.

var i;
for (i = 1; i <= 10; i += 1) {
    console.log(i);
}